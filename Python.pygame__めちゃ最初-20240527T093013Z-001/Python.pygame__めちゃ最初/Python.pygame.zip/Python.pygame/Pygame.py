from pygame.locals import *
import pygame
import sys


def draw(screen, player_image, mouse_pos,img3):
        screen.fill(pygame.Color("white"))
        screen.blit(player_image, mouse_pos)
        mouse_x, mouse_y = mouse_pos
        screen.blit(img3, (mouse_x + 20, mouse_y - 0))
        pygame.display.update()



def main():
     pygame.init()
     screen = pygame.display.set_mode((600, 400))    
     player_image = pygame.image.load("画像/ｔame.png").convert()
     img3 = pygame.image.load("画像/スライム（背景なし）.png")
     #img3 = pygame.transform.scale(img3, (200, 130))
     
     while True:
        
        pygame.event.clear()
        key_pressed = pygame.key.get_pressed()
        if key_pressed[pygame.K_ESCAPE]:
            break
        mouse_pos = pygame.mouse.get_pos()

        draw(screen, player_image, mouse_pos,img3)

     pygame.quit()


main()